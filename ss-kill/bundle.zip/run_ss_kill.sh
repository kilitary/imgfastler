#!/bin/sh
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
for LD in "$DIR"/lib/ld-linux*.so.* "$DIR"/lib/ld-*.so.*; do
  if [ -x "$LD" ]; then
    exec "$LD" --library-path "$DIR/lib" "$DIR/ss-kill" "$@"
  fi
done
LD_LIBRARY_PATH="$DIR/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" exec "$DIR/ss-kill" "$@"
